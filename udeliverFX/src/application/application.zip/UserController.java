package application;
import javafx.scene.layout.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.*;


public class UserController implements Initializable{
	@FXML
	private AnchorPane rootPane;

	@Override 
	public void initialize(URL url,ResourceBundle rb)
	{
		
	}
}
