package application;

import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.*;

public class SampleController implements Initializable {
	@FXML
	private AnchorPane rootPane;
	@FXML
	private HBox User;

	@Override
	public void initialize(URL url, ResourceBundle rb) {

	}

	@FXML
	private void LoadUser(MouseEvent event) throws IOException {
		AnchorPane UserPane = (AnchorPane) FXMLLoader.load(getClass().getResource("UserPane.fxml"));
		rootPane.getChildren().setAll(UserPane);
	}

}
