package application;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.*;


public class CustomerController implements Initializable{
	@FXML
	private AnchorPane rootPane;
	@FXML
	private TableView<CustomerTable> customer;
	@FXML
	private TableColumn<CustomerTable,String> Address;
	@FXML
	private TableColumn<CustomerTable,String> TotalTip;
	@FXML
	private TableColumn<CustomerTable,String> visits;
	@FXML
	private TableColumn<CustomerTable,String> Average;
	@FXML
	private TableColumn<CustomerTable,Button> AddDelivery;
	@FXML
	private TableColumn<CustomerTable,Button> DeleteCustomer;
	ObservableList<CustomerTable> oblist = FXCollections.observableArrayList(); 
	@Override 
	public void initialize(URL url,ResourceBundle rb)
	{		try {
		String Query = "SELECT * FROM customer ";
		Connection con = Connect.getConnection();
		PreparedStatement ps = con.prepareStatement(Query);
		ResultSet rs = ps.executeQuery();
		
		while(rs.next()) {
			Button addBtn = new Button("+");
			Button deleteBtn = new Button("-");
			float TipOnAverage = rs.getFloat("TotalTip") / rs.getInt("visits");
			oblist.add(new CustomerTable(rs.getString("Address"),Float.toString(rs.getFloat("TotalTip")),Integer.toString(rs.getInt("visits")),Float.toString(TipOnAverage),addBtn,deleteBtn));
			}
		
	}catch(SQLException ex) {
		Logger.getLogger(RestaurantController.class.getName()).log(Level.SEVERE,null,ex);
	}
	Address.setCellValueFactory(new PropertyValueFactory<>("Address"));
	TotalTip.setCellValueFactory(new PropertyValueFactory<>("TotalTip"));
	visits.setCellValueFactory(new PropertyValueFactory<>("visits"));
	Average.setCellValueFactory(new PropertyValueFactory<>("Average"));
	AddDelivery.setCellValueFactory(new PropertyValueFactory<>("add"));
	DeleteCustomer.setCellValueFactory(new PropertyValueFactory<>("Delete"));
	
	customer.setItems(oblist);
	}
	@FXML
	private void LoadDash(MouseEvent event) throws IOException {

			AnchorPane DashPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/newUI.fxml"));
			rootPane.getChildren().setAll(DashPane);
			
	}
	@FXML
	private void LoadUser(MouseEvent event) throws IOException {

			AnchorPane UserPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/UserPanel.fxml"));
			rootPane.getChildren().setAll(UserPane);
			
	}
	@FXML
	private void LoadExpense(MouseEvent event) throws IOException {

			AnchorPane ExpensePane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/ExpensesPane.fxml"));
			rootPane.getChildren().setAll(ExpensePane);
			
	}
	@FXML
	private void LoadRestaurant(MouseEvent event) throws IOException {

			AnchorPane RestaurantPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/RestaurantPane.fxml"));
			rootPane.getChildren().setAll(RestaurantPane);
			
	}
	@FXML
	private void LoadAD(ActionEvent event) throws IOException {

			AnchorPane AddDeliveryPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/AddDelivery.fxml"));
			rootPane.getChildren().setAll(AddDeliveryPane);
			
	}
}