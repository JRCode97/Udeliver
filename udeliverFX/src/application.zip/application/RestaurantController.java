package application;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.*;


public class RestaurantController extends MainController implements Initializable{
	@FXML
	private AnchorPane rootPane;
	int userID = 0;
	@FXML 
	private TableView<ModelRestaurantTable> restaurants;
	@FXML 
	private TableColumn<ModelRestaurantTable,String> col_Name;
	@FXML
	private TableColumn<ModelRestaurantTable,String> col_wage;
	@FXML
	private TableColumn<ModelRestaurantTable,String> col_weeklyHours;
	@FXML 
	private TableColumn<ModelRestaurantTable,String> Col_WeeklyPay;
	@FXML
	private TableColumn<ModelRestaurantTable,String> Col_WeekTip;
	@FXML
	private TableColumn<ModelRestaurantTable,String> Col_TotalinWeek;
	@FXML
	private TableColumn<ModelRestaurantTable,String> Col_AllTimeTotal;
	 
	ObservableList<ModelRestaurantTable> oblist = FXCollections.observableArrayList(); 
	public void setUser(int user) {
		userID = user;
	}
	public int getUser() {
		return userID;
	}
	@Override 
	public void initialize(URL url,ResourceBundle rb)
	{
		//System.out.println(thisuser.getFirstName());
		//loadData();
	}
	public void loadData() throws SQLException {
		int RestID = 0;
		try {
			Connection con = Connect.getConnection();
			String getID = "SELECT RestaurantID FROM driversrestaurant WHERE DriverID = '"+userID+"' ";
			PreparedStatement get = con.prepareStatement(getID);
			ResultSet id = get.executeQuery();
			while(id.next()){
				System.out.println("");
				RestID = id.getInt("ID");
			
					String Query = "SELECT * FROM restaurant,driversrestaurant WHERE ID = '"+RestID+"' AND driversrestaurant.restaurantID = restaurant.ID ";

					PreparedStatement ps = con.prepareStatement(Query);
					ResultSet rs = ps.executeQuery();
					
					while(rs.next()) {
						System.out.println("found info");
						Float payforWeek =  rs.getFloat("weekHoursWorked") * rs.getFloat("Wage");
						Float WeekTip = rs.getFloat("TipInWeek");
						Float totalWeek = payforWeek + WeekTip;
						String payForWeek = Float.toString(payforWeek);
						String weekTip = Float.toString(payforWeek);
						String TotalWeek = Float.toString(totalWeek);				
						System.out.println(payForWeek);
						System.out.println(weekTip);
						oblist.add(new ModelRestaurantTable(rs.getString("name"),Float.toString(rs.getFloat("Wage")),Float.toString(rs.getFloat("WeekHoursWorked")),payForWeek,Float.toString(rs.getFloat("TipinWeek")),TotalWeek,Float.toString(rs.getFloat("AllTimeTotal"))));
						}
					
		
			}
				
			}
		catch(SQLException ex) {
			System.out.println("driverrest failed");

		}
		col_Name.setCellValueFactory(new PropertyValueFactory<>("name"));
		col_wage.setCellValueFactory(new PropertyValueFactory<>("wage"));
		col_weeklyHours.setCellValueFactory(new PropertyValueFactory<>("weeklyHours"));
		Col_WeeklyPay.setCellValueFactory(new PropertyValueFactory<>("WeekPay"));
		Col_WeekTip.setCellValueFactory(new PropertyValueFactory<>("WeekTip"));
		Col_TotalinWeek.setCellValueFactory(new PropertyValueFactory<>("TotalinWeek"));
		Col_AllTimeTotal.setCellValueFactory(new PropertyValueFactory<>("AllTime"));
		restaurants.setItems(oblist);
		
	}
	@FXML
	private void LoadDash(MouseEvent event) throws IOException {

			AnchorPane DashPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/newUI.fxml"));
			rootPane.getChildren().setAll(DashPane);
			
	}
	@FXML
	private void LoadUser(MouseEvent event) throws IOException {

			AnchorPane UserPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/UserPanel.fxml"));
			rootPane.getChildren().setAll(UserPane);
			
	}
	@FXML
	private void LoadExpense(MouseEvent event) throws IOException {

			AnchorPane ExpensePane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/ExpensesPane.fxml"));
			rootPane.getChildren().setAll(ExpensePane);
			
	}
	@FXML
	private void LoadCustomer(MouseEvent event) throws IOException {

			AnchorPane CustomerPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/CustomerPane.fxml"));
			rootPane.getChildren().setAll(CustomerPane);
			
	}
	@FXML
	private void LoadAR(ActionEvent event) throws IOException {

		System.out.println("AR running");
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/application/AddRestaurant.fxml"));
		AnchorPane ARPane = (AnchorPane) loader.load();
		ARController controller = loader.getController();
		controller.setUserID(userID);
		rootPane.getChildren().setAll(ARPane);
			
	}

}