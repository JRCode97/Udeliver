package application;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.mysql.jdbc.Connection;

import javafx.event.ActionEvent;
import javafx.fxml.*;


public class ExpenseController implements Initializable{
	@FXML
	private AnchorPane rootPane;
	@FXML
	private TextField MGTF;
	@FXML
	private TextField CPTF;	
	@FXML
	private TextField ITF;	
	@FXML
	private TextField MTF;	
	@FXML
	private Label TotalTxt;
	@Override 
	public void initialize(URL url,ResourceBundle rb)
	{
		
	}
	@FXML
	private void LoadDash(MouseEvent event) throws IOException {

			AnchorPane DashPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/newUI.fxml"));
			rootPane.getChildren().setAll(DashPane);
			
	}
	@FXML
	private void LoadUser(MouseEvent event) throws IOException {

			AnchorPane UserPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/UserPanel.fxml"));
			rootPane.getChildren().setAll(UserPane);
			
	}
	@FXML
	private void LoadRestaurant(MouseEvent event) throws IOException {

		
			AnchorPane RestaurantPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/RestaurantPane.fxml"));
			rootPane.getChildren().setAll(RestaurantPane);
			
	}
	@FXML
	private void LoadCustomer(MouseEvent event) throws IOException {

			AnchorPane CustomerPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/CustomerPane.fxml"));
			rootPane.getChildren().setAll(CustomerPane);
			
	}
	@FXML
	private void LoadAD(ActionEvent event) throws IOException {

			AnchorPane AddDeliveryPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/AddDelivery.fxml"));
			rootPane.getChildren().setAll(AddDeliveryPane);
			
	}
	@FXML
	private void TotalUp(ActionEvent event) throws SQLException
	{	Connection con = Connect.getConnection();
		
		float Gas = Float.parseFloat(MGTF.getText());
		float CarPayment = Float.parseFloat(CPTF.getText());
		float Insurance = Float.parseFloat(ITF.getText());
		float Maintenance = Float.parseFloat(MTF.getText());
		float Total = Gas+ CarPayment + Insurance + Maintenance;
		TotalTxt.setText(Float.toString(Total));
		String Query = "INSERT INTO expenses (ExpenseID,Gas,CP,Insurance,Maintenance,DriverID) VALUES(0,?,?,?,?,?) ";
		PreparedStatement ps = con.prepareStatement(Query);
		ps.setFloat(1, Gas);
		ps.setFloat(2, CarPayment);
		ps.setFloat(3, Insurance);
		ps.setFloat(4, Maintenance);
		ps.setInt(5, 7);
		ps.executeUpdate();
		
	}
}