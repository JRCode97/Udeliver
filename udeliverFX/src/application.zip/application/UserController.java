package application;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.mysql.jdbc.Connection;

import javafx.event.ActionEvent;
import javafx.fxml.*;

public class UserController implements Initializable{
		@FXML
		private AnchorPane rootPane;
		@FXML
		private Button EditBtn;
		@FXML
		private TextField FNTF;
		@FXML 
		private TextField LNTF;
		@FXML
		private TextField ETF;
		@FXML
		private TextField PTF;
		private int UserID;
		public void setUser(int userID) {
			UserID = userID;
		}
		public int getUser() {
			return UserID;
		}
		@Override 
		public void initialize(URL url,ResourceBundle rb)
		{
			
		}
		
		@FXML
		private void LoadDash(MouseEvent event) throws IOException {

				AnchorPane DashPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/newUI.fxml"));
				rootPane.getChildren().setAll(DashPane);
				
		}
		@FXML
		private void LoadExpense(MouseEvent event) throws IOException {

				AnchorPane ExpensePane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/ExpensesPane.fxml"));
				rootPane.getChildren().setAll(ExpensePane);
				
		}
		@FXML
		private void LoadCustomer(MouseEvent event) throws IOException {

				AnchorPane CustomerPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/CustomerPane.fxml"));
				rootPane.getChildren().setAll(CustomerPane);
				
		}
		@FXML
		private void LoadRestaurant(MouseEvent event) throws IOException {

				AnchorPane RestaurantPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/RestaurantPane.fxml"));
				rootPane.getChildren().setAll(RestaurantPane);
				
		}
		@FXML
		private void LoadAD(ActionEvent event) throws IOException {

				AnchorPane AddDeliveryPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/AddDelivery.fxml"));
				rootPane.getChildren().setAll(AddDeliveryPane);
				
		}
		@FXML
		private void EditUser(MouseEvent event) throws SQLException {
			
			System.out.println("Running Edit");
			//String email = signINController.this.user.getEmail();
			Connection con = Connect.getConnection();
			if (!FNTF.getText().equals("")) {
			String FN =  FNTF.getText();
			String FNQuery = "UPDATE drivers SET FirstName = ? WHERE Email = '"+UserID+"'";
			String fn = FNTF.getText();
			PreparedStatement fnps = con.prepareStatement(FNQuery);
			fnps.setString(1, fn);
			}
			if(!LNTF.getText().equals("")) {
			String LN =  LNTF.getText();
			String LNQuery = "UPDATE drivers SET LastName = ? WHERE Email = '"+UserID+"'";
			String ln = FNTF.getText();
			PreparedStatement lnps = con.prepareStatement(LNQuery);
			lnps.setString(1, ln);
			lnps.executeUpdate();}
			if(ETF.getText().equals("")) {
			String Email =  ETF.getText();
			String	EMQuery = "UPDATE drivers SET Email = ? WHERE Email = '"+UserID+"'";
			String email = FNTF.getText();
			PreparedStatement emps = con.prepareStatement(EMQuery);
			emps.setString(1, email);
			emps.executeUpdate();
			}
			if(PTF.getText() != null) {
			String NewPword = PTF.getText();
			String PWQuery = "UPDATE drivers SET Password = ? WHERE Email = '"+UserID+"'";
			String pw = FNTF.getText();
			PreparedStatement pwps = con.prepareStatement(PWQuery);
			pwps.setString(1, pw);
			pwps.executeUpdate();
			}
			
			
			PreparedStatement ps = con.prepareStatement(Query);
			
			ps.executeUpdate();
		}
}
