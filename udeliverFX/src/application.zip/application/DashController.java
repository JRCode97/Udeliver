package application;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.*;

public class DashController implements Initializable {
	@FXML
	private AnchorPane rootPane;
	@FXML
	private Button User;
	private int userID;
	public void setUser(int user) {
		userID = user;
		System.out.println(userID);
	}
	public int getUser() {
		return userID;
	}
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		
	}

	@FXML
	private void LoadExpense(MouseEvent event) throws IOException {

			AnchorPane ExpensePane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/ExpensesPane.fxml"));
			rootPane.getChildren().setAll(ExpensePane);
			
	}
	@FXML
	private void LoadUser(MouseEvent event) throws IOException {

			AnchorPane UserPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/UserPanel.fxml"));
			rootPane.getChildren().setAll(UserPane);
			
	}
	@FXML
	private void LoadRestaurant(MouseEvent event) throws IOException, SQLException {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/application/RestaurantPane.fxml"));
			AnchorPane RestaurantPane = (AnchorPane) loader.load();
			RestaurantController controller = loader.getController();
			controller.setUser(userID);
			controller.loadData();
			
			//AnchorPane RestaurantPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/RestaurantPane.fxml"));
			rootPane.getChildren().setAll(RestaurantPane);
			System.out.println("restaurant running");
			
		
	}
	@FXML
	private void LoadCustomer(MouseEvent event) throws IOException {

			AnchorPane CustomerPane = (AnchorPane) FXMLLoader.load(getClass().getResource("/application/CustomerPane.fxml"));
			rootPane.getChildren().setAll(CustomerPane);
			
	}
	@FXML
	private void LoadAR(ActionEvent event) throws IOException {
		System.out.println("AR running");
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/application/AddRestaurant.fxml"));
		AnchorPane ARPane = (AnchorPane) loader.load();
		ARController controller = loader.getController();
		controller.setUserID(userID);
		rootPane.getChildren().setAll(ARPane);
	}
	@FXML
	private void LoadAD(ActionEvent event) throws IOException, SQLException {
		System.out.println("AD running");
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/application/AddDelivery.fxml"));
		AnchorPane ADPane = (AnchorPane) loader.load();
		ADController controller = loader.getController();
		controller.LoadRestaurantList(userID);
		System.out.println("Dash ID:"+ userID);
		controller.setUserID(userID);
		rootPane.getChildren().setAll(ADPane);
	}
}
